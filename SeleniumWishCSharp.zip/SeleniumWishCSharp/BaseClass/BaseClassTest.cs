﻿namespace SeleniumWishCSharp.BaseClass
{
    public class BaseClassTest
    {
    }
}
