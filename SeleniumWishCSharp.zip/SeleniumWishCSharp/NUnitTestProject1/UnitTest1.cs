using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace NUnitTestProject1
{
    [TestFixture]
    public class Tests
    {
        IWebDriver webDriver;
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void Test1()
        {
            webDriver = new ChromeDriver();
            webDriver.Url = "https://www.facebook.com/";
            Assert.Pass();
        }
    }
}